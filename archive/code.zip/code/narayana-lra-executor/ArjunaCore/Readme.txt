If you are going to use the ExecProcessId implementation to obtain a pid, rather than one of the other implementations, then you need to download getpids.exe if you are also running on Windows.

Download from http://www.scheibli.com/projects/getpids/ and place it within your classpath.

Note that you should always try to download the latest version, but a cached copy is now in the ext directory.
