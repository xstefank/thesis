package com.arjuna.ats.arjuna.objectstore;

/**
 * Created by IntelliJ IDEA.
 * User: jhalli
 * Date: Jul 6, 2010
 * Time: 5:51:04 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ObjectStoreAPI extends ParticipantStore, RecoveryStore
{
}
