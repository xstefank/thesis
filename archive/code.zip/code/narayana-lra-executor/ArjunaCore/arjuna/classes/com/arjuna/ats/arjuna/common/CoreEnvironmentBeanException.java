package com.arjuna.ats.arjuna.common;

public class CoreEnvironmentBeanException extends Exception {

	public CoreEnvironmentBeanException(String string) {
		super(string);
	}

}
