package org.learn.eventuate.invoiceservice.command;

import io.eventuate.Command;

public interface InvoiceCommand extends Command {
}
