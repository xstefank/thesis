package org.learn.eventuate.orderservice.command.saga;

public class ShipmentCompensatedCommand implements OrderSagaCommand {

}
