package org.learn.eventuate.orderservice.command;

import io.eventuate.Command;

public interface OrderCommand extends Command {
}
