package org.learn.eventuate.orderservice.domain.event;

public class InvoiceCompensatedEvent implements OrderSagaEvent {
}
