package org.learn.eventuate.orderservice.command.saga;

public class InvoiceCompensatedCommand implements OrderSagaCommand {
    
}
