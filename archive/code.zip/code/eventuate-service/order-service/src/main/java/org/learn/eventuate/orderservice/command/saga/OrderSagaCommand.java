package org.learn.eventuate.orderservice.command.saga;

import io.eventuate.Command;

public interface OrderSagaCommand extends Command {
}
