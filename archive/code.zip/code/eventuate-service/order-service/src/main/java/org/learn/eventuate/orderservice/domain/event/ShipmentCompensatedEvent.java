package org.learn.eventuate.orderservice.domain.event;

import io.eventuate.Event;

public class ShipmentCompensatedEvent implements Event {

}
