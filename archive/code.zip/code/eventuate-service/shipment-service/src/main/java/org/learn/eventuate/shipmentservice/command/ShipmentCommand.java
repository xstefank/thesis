package org.learn.eventuate.shipmentservice.command;

import io.eventuate.Command;

public interface ShipmentCommand extends Command {
}
