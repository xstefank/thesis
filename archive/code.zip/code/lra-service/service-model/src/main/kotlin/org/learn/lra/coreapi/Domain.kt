package org.learn.lra.coreapi

data class ProductInfo(val productId: String = "", val comment: String = "", val price: Int = 0)

