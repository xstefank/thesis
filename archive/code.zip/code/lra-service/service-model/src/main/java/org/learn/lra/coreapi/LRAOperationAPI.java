package org.learn.lra.coreapi;

public interface LRAOperationAPI {

    String REQUEST = "/request";
    String COMPLETE = "/complete";
    String COMPENSATE = "/compensate";


}
