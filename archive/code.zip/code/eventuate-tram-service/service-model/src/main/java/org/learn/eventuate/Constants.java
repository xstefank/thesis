package org.learn.eventuate;

public class Constants {

    public static final String ORDER_SERVICE = "orderservice";

    public static final String SHIPMENT_SERVICE = "shipmentservice";

    public static final String INVOCE_SERVICE = "invoiceservice";

}
