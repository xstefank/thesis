package org.xstefank.lra.execution.model;

public enum LRAOutcome {

    COMPLETED,
    NEED_COMPENSATION //TODO rename to COMPENSATED when merged with lra-coordinator
}
