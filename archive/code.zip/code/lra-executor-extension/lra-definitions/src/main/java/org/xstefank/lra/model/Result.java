package org.xstefank.lra.model;

public enum Result {

    SUCCESS,
    FAILURE
}
